
class Ling():

